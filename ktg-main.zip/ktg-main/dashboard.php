<?php include('header.php'); ?>

<style>
    .text-banger {
        color: red;
    }
</style>
<div class="side-menu">
        <div class='side-menu-body' id="menu_page">
            <!--- ajax page---->
            <ul>
                <li><a href="dashboard.php"><i class="icon fa fa-home"><span>Dashboards</span></i></a></li>
                <li class="side-menu-divider">Menu</li>
                <li><a href="javascript:void(0);"><i class="icon fa fa-hashtag"><span>Master</span></i></a>
                    <ul>
                        <li><a href="email_details.php">Email DataBasic</a></li>
                        <li><a href="suppression_details.php">Suppression Details</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript:void(0);"><i class="icon fa fa-wrench"><span>Tools</span></i></a>
                    <ul>
                        <li><a href="download_tool_details.php">Download Tool</a></li>
                        <li><a href="download_tool_list.php">Download Tool List</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
<!-- begin::main content -->
<main class="main-content">

</main>
<!-- end::main content -->
<?php include('footer.php'); ?>