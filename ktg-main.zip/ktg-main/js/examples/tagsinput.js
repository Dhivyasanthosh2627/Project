'use strict';
$(document).ready(function () {

    $("input.tagsinput").tagsinput('items');

});